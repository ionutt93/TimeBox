coffee -c *.coffee
compass compile
