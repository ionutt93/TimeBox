angular.module('sampleApp', 
	['ngRoute', 'appRoutes', 'MainCtrl', 'LoginCtrl',
	 'ProjectCtrl', 'TaskService', 'TimerCtrl', 
	 'GroupService', 'ui.slider', 'myTaskDirective',
	 'myGroupDirective', 'myDragAndDropDirective']);
