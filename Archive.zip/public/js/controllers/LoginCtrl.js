'use strict'

angular.module('LoginCtrl', []).controller("LoginController", 
	["$scope", function ($scope) {

}]);