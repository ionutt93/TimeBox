'use strict'
module.exports = {
    dev_url: 'mongodb://localhost:27017/development',
    prod_url: 'mongodb://ioan:troll4life@dogen.mongohq.com:10062/app31190733',
    test_url: 'mongodb://localhost:27017/test'
};
